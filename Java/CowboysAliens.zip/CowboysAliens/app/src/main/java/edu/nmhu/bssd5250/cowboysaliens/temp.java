package edu.nmhu.bssd5250.cowboysaliens;

public class temp {
}
